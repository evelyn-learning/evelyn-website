SOLARO AI Solution packet, PREMIUM grade - Item 239622 (Chemistry 30, numerical response)
Prototype prepared by Evelyn Learning for Castle Rock Research technical review.

CONTENTS
  solution.html      The whole solution in one file: the board (inline SVG), the player, the written
                     steps and the small script that runs them. UTF-8. No external requests.
  audio/step-1.mp3   Tutor voice for each step (MP3, mono, 96 kbps). One file per step.
  ... step-5.mp3

HOW TO SHOW IT
  Place the folder on your server and point an iframe at solution.html, for example:

    <iframe src="/path/to/239622/solution.html" width="100%" height="620"
            title="AI solution for item 239622" style="border:0"></iframe>

  The height is set per item and is listed here: 620 px for this item. The page lays itself out
  inside the frame: the board and the live caption stay in view while the voice plays and the
  written solution scrolls beside them (wide frame) or below them (narrow frame). The page never
  scrolls the surrounding document.

WHAT IT DOES AND DOES NOT DO
  - Everything is inside this folder. No web fonts, no tracking, no request to any other server.
  - Plain script, no libraries. Audio through the standard audio element.
  - The written solution is readable with the script off; the board then shows its final state.
  - The answer is stated first, then the steps.

STILL TO DO BEFORE DELIVERY (prototype note)
  - Class names will carry the "es-" prefix throughout and body text will be set at 12pt
    Arial/Helvetica/Verdana to match your solution panel.
  - Any equation that cannot be typed as text will be supplied as a PNG in your rasterised style.

(c) 2026 Evelyn Learning
